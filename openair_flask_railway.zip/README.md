# OpenAir Flask API para Railway

## Como usar no Railway:

1. Crie um projeto novo em https://railway.app
2. Clique em "Deploy from GitHub repo" ou envie este zip manualmente
3. Railway vai detectar o `requirements.txt` e `Procfile`
4. Acesse a URL gerada e use `/run_openair` com sua interface web

Exemplo:
https://openair-api-production.up.railway.app/run_openair